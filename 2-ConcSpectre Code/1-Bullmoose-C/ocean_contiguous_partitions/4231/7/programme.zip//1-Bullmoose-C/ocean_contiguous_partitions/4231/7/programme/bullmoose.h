#include <stdio.h>

void recordMessage();
void malicious_start();
void malicious_end();

void malicious_1();
void malicious_2();
void malicious_3();
void malicious_4();
